package com.mikel.controller;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;

import com.mikel.model.Carrito;
import com.mikel.model.Color;
import com.mikel.model.InventarioColores;
import com.mikel.model.InventarioMateriales;
import com.mikel.model.InventarioTallas;
import com.mikel.model.InvoiceItem;
import com.mikel.model.Material;
import com.mikel.model.ProductoComprado;
import com.mikel.model.Ropa;
import com.mikel.model.Talla;
import com.mikel.model.TicketFinal;
import com.mikel.model.Usuario;
import com.mikel.repository.CarritoRepository;
import com.mikel.repository.ColorRepository;
import com.mikel.repository.InventarioColoresRepository;
import com.mikel.repository.InventarioMaterialesRepository;
import com.mikel.repository.InventarioTallasRepository;
import com.mikel.repository.MaterialRepository;
import com.mikel.repository.ProductoCompradoRepository;
import com.mikel.repository.RopaRepository;
import com.mikel.repository.TallaRepository;
import com.mikel.repository.TicketFinalRepository;
import com.mikel.repository.UsuarioRepository;

import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;
import jakarta.servlet.http.HttpSession;

@Controller
public class AdminController {

	@Autowired
	private RopaRepository ropaRepo;
	
	@Autowired
	private UsuarioRepository usuarioRepo;
	
    @Autowired
    private JavaMailSender mailSender;
    
	@Autowired
	private MaterialRepository materialRepo;
	
	@Autowired
	private ColorRepository colorRepo;
	
	@Autowired
	private InventarioColoresRepository inventarioColoresRepo;
	
	@Autowired
	private InventarioTallasRepository inventarioTallasRepo;
	
	@Autowired
	private InventarioMaterialesRepository inventarioMaterialesRepo;
	
	@Autowired
	private CarritoRepository carritoRepo;
	
	@Autowired
	private TallaRepository tallaRepo;
	
	@Autowired
	private TicketFinalRepository ticketFinalRepo;
	
	@Autowired
	private ProductoCompradoRepository productoCompradoRepo;
	
    @Autowired
    private TemplateEngine templateEngine;
	
    // Controlador para recoger los datos necesarios para la primera pagina y despues llamarla
	@RequestMapping("/index")
	public String paginaPrincipal(Model model, HttpSession session) {
		
		// Para saber quien es el usuario que se ha loggeado
		Optional<Usuario> usuarioLocalizado = usuarioRepo.findById((Integer) session.getAttribute("usuario"));
		
		// Las listas de elementos necesarios
		model.addAttribute("atr_lista_ropa", ropaRepo.findAll());
		
		model.addAttribute("atr_lista_carrito", carritoRepo.findAll());
		
		List<Carrito> listaCarrito = carritoRepo.findByUsuarioId(usuarioLocalizado.get().getId());
		
		// Numero de elementos en el carrito
		model.addAttribute("numeroCarrito", listaCarrito.size());
		
		return "index";
	}
	
	// Controlador para llamar al login de la pagina
	@RequestMapping("/login")
	public String login(Model model, HttpSession session) {
		
		// Recogemos los datos de los intentos de inicio de sesion por si esta bloqueada la sesion
		Integer numeroDeIntentos = (Integer) session.getAttribute("numero_de_intentos");
				
		model.addAttribute("mensaje_de_error", "Nombre de usuario o contraseña incorrecta. <br> Numero de intentos antes del bloqueo: " + numeroDeIntentos);
		
		if (numeroDeIntentos == 0) {
			return "bloqueo";
		} else {
			return "login";
		}

	}
	
	// Controlador que llama a la pagina de crear una cuenta nueva
	@RequestMapping("/crearCuenta")
	public String crearCuenta(Model model) {
		
		return "CuentaNueva";

	}
	
	// Controlador para comprobar el inicio de sesion
	@RequestMapping("/loginComprobar")
	public String loginComprobar(Model model, HttpSession session , @RequestParam("correo") String correo, @RequestParam("contra") String contra) throws NoSuchAlgorithmException {
		
		List<Usuario> usuarioLocalizado = usuarioRepo.findByCorreo(correo);
		
		Integer numeroDeIntentos = (Integer) session.getAttribute("numero_de_intentos");
		
		// Se hashea la contraseña introducida para compararlo con la guardada
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        byte[] hashedBytes = md.digest(contra.getBytes());
        StringBuilder sb = new StringBuilder();
        for (byte b : hashedBytes) {
            sb.append(String.format("%02x", b));
        }
        
        String contraHasheada = sb.toString();
		
        // Se validacion es correcta o no
        // Si es correcta entra y se resetean los intentos de inicio de sesion
        // Sino se quita 1 a la cantidad de intentos restantes y vuelve a llamar al login
		if (usuarioLocalizado.get(0).getContra().equals(contraHasheada)) {
			
			session.removeAttribute("numero_de_intentos");
			
			session.setAttribute("numero_de_intentos", 3);
			
			session.setAttribute("usuario", usuarioLocalizado.get(0).getId());
						
			return "redirect:/index";
		} else {
						
			numeroDeIntentos = numeroDeIntentos - 1;
			
			session.removeAttribute("numero_de_intentos");
			
			session.setAttribute("numero_de_intentos",numeroDeIntentos);
						
			return "redirect:/login";
		}
		
	}
	
	// Controlador para llamar a la pagina de olvidarContraseñaPagina
	@RequestMapping("/olvidarContraseñaPagina")
	public String olvidarContraseñaPagina(Model model) {
		
		
		return "olvidarContraseñaPagina";
	}
	
	// Controlador para llamar a la pagina de ajustes
	@RequestMapping("/ajustes")
	public String ajustes(Model model, HttpSession session) {
		
		Optional<Usuario> usuarioLocalizado = usuarioRepo.findById((Integer) session.getAttribute("usuario"));
		
		// Si es usuario tienen permiso de entrar ira a admin, sino a la de cambio de contraseña
		if (usuarioLocalizado.get().getPermiso() == 1) {
			
			model.addAttribute("atr_lista_ropa", ropaRepo.findAll());
			
			return "admin";
		} else {
			model.addAttribute("correoUsuario", usuarioLocalizado.get().getCorreo());
			
			return "cambiarContraseña";
			
		}
		
	}
	
	// Controlador para ir a la pagina de modificar
	@RequestMapping("/paginaModificarRopa")
	public String paginaModificarRopa(Model model, @RequestParam("idRopa") int idRopa) {
		
		Optional<Ropa> ropaOptional = ropaRepo.findById(idRopa);
		
		model.addAttribute("atr_lista_ropa", ropaOptional.get());
			
		return "adminModificar";
		
	}
	
	// Controlador para ir a la pagina de modificarRopa
	@RequestMapping("/modificarRopa")
	public String modificarRopa(Model model, @RequestParam("idRopa") int idRopa, @RequestParam("nombre") String nombre, @RequestParam("descripcion") String descripcion, @RequestParam("precio") double precio) {
		
		ropaRepo.updateRopaById(idRopa, nombre, descripcion, precio);
		
		model.addAttribute("atr_lista_ropa", ropaRepo.findAll());
			
		return "admin";
		
	}
	
	// Controlaro para borrar la ropa por su id
	@RequestMapping("/borrarRopa")
	public String borrarRopa(Model model, @RequestParam("idRopa") int idRopa) {
		
		ropaRepo.deleteByIdRopa(idRopa);
		
		model.addAttribute("atr_lista_ropa", ropaRepo.findAll());
			
		return "admin";
		
	}
	
	// Controlador para ir a la info del producto
	@RequestMapping("/infoProducto")
	public String infoProducto(Model model, @RequestParam("idRopa") int idRopa) {
		
		Optional<Ropa> ropa = ropaRepo.findById(idRopa);
		
		List<InventarioColores> colorLista = inventarioColoresRepo.findByRopaId(idRopa);
		
		List<InventarioTallas> tallaLista = inventarioTallasRepo.findByRopaId(idRopa);
		
		List<InventarioMateriales> materialLista = inventarioMaterialesRepo.findByRopaId(idRopa);
		
		model.addAttribute("ropa", ropa.get());
		
		model.addAttribute("atr_lista_color", colorLista);
		
		model.addAttribute("atr_lista_talla", tallaLista);
		
		model.addAttribute("atr_lista_material", materialLista);
		
		return "infoRopa";
	}
	
	// Controlador por si el usuario olvida la contraseña y desea que le manden una nueva al corrreo
	@RequestMapping("/olvidarContraseña")
	public String olvidarContraseña(Model model, @RequestParam("correo") String correo) throws NoSuchAlgorithmException {
		
		List<Usuario> usuarioLocalizado = usuarioRepo.findByCorreo(correo);
		
		// Se genera una contraseña aleatoria
		List<Character> listaAleatoria = new ArrayList<>();
		
		listaAleatoria.add('A');
		listaAleatoria.add('B');
		listaAleatoria.add('C');
		listaAleatoria.add('D');
		listaAleatoria.add('E');
		
		Collections.shuffle(listaAleatoria);
		
		// Convertimos de una lista a un String
        StringBuilder nuevaContra = new StringBuilder();
        for (Character c : listaAleatoria) {
            nuevaContra.append(c);
        }
        
        String contraFinal = nuevaContra.toString();
        
		// Se hashea la contraseña introducida
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        byte[] hashedBytes = md.digest(contraFinal.getBytes());
        StringBuilder sb = new StringBuilder();
        for (byte b : hashedBytes) {
            sb.append(String.format("%02x", b));
        }
        
        String contraHasheada = sb.toString();
        
        // Actualizamos la contraseña
        usuarioRepo.updatePasswordByCorreo(correo, contraHasheada);
		
        // Mandamos el correo a usuario
        SimpleMailMessage message = new SimpleMailMessage();
        message.setTo(correo);
        message.setSubject("Mensaje de recuperaciòn de contraseña");
        message.setText("Buenos dias, aqui tiene su contraseña temporal para poder iniciar sesion: " + contraFinal);
        message.setFrom("PruebasMikelUrle@gmail.com");
        mailSender.send(message);
		
		return "redirect:/login";

	}
	
	// Controlador para cambiar la contraseña
	@RequestMapping("/cambiarContraseña")
	public String cambiarContraseña(Model model, @RequestParam("correo") String correo, @RequestParam("contra") String contra) throws NoSuchAlgorithmException {
        
		// Se hashea la contraseña introducida para compararlo con la guardada
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        byte[] hashedBytes = md.digest(contra.getBytes());
        StringBuilder sb = new StringBuilder();
        for (byte b : hashedBytes) {
            sb.append(String.format("%02x", b));
        }
        
        String contraHasheada = sb.toString();
        
        usuarioRepo.updatePasswordByCorreo(correo, contraHasheada);
		
		return "redirect:/index";

	}
	
	// Controlador para poder agregar ropa al carrito
	@RequestMapping("/agregarRopaCarrito")
	public String agregarRopaCarrito(Model model, HttpSession session, @RequestParam("color") String color, @RequestParam("idRopa") int idRopa, @RequestParam("talla") String talla) {
        
		Optional<Usuario> usuarioLocalizado = usuarioRepo.findById((Integer) session.getAttribute("usuario"));
		
		Color colorInsert = colorRepo.findByNombre(color);
		
		Talla tallaInsert = tallaRepo.findByLetra(talla);
		
		Optional<Ropa> ropaInsert = ropaRepo.findById(idRopa);
		
		Carrito nuevoCarrito = new Carrito();
		
		nuevoCarrito.setColor(colorInsert);
		nuevoCarrito.setRopa(ropaInsert.get());
		nuevoCarrito.setTalla(tallaInsert);
		nuevoCarrito.setUsuario(usuarioLocalizado.get());
		
		carritoRepo.save(nuevoCarrito);
		
		return "redirect:/index";

	}
	
	// Controlador para ir a la pagina principal despues de filtrar
	@RequestMapping("/paginaPrincipalFiltro")
	public String paginaPrincipalFiltro(Model model, @RequestParam("categoriaId") int categoriaId) {
		
		model.addAttribute("atr_lista_ropa", ropaRepo.findByCategoria(categoriaId));
		
		return "index";
	}
	
	// Controlador para ir a la pagina principal despues del filtro de estado
	@RequestMapping("/paginaPrincipalFiltroEstado")
	public String paginaPrincipalFiltroEstado(Model model, @RequestParam("estadoId") int estadoId) {
		
		model.addAttribute("atr_lista_ropa", ropaRepo.findByEstado(estadoId));
		
		return "index";
	}
	
	// Controlador para ir a la pagina principal despues del filtro de la coleccion
	@RequestMapping("/paginaPrincipalFiltroColeccion")
	public String paginaPrincipalFiltroColeccion(Model model, @RequestParam("coleccionId") int coleccionId) {
		
		model.addAttribute("atr_lista_ropa", ropaRepo.findByColeccion(coleccionId));
		
		return "index";
	}
	
	// Controlador para ir a la pagina del carrito
	@RequestMapping("/carritoPagina")
	public String carritoPagina(Model model, HttpSession session) {
		
		Optional<Usuario> usuarioLocalizado = usuarioRepo.findById((Integer) session.getAttribute("usuario"));

		model.addAttribute("atr_lista_carrito", carritoRepo.findByUsuarioId(usuarioLocalizado.get().getId()));
		
		List<Carrito> carritoPalDinero = carritoRepo.findByUsuarioId(usuarioLocalizado.get().getId());
		
		// Calculo del precio total
		double precioTotal = 0.0;
		
		for (Carrito carritoElemento : carritoPalDinero) {
			precioTotal = precioTotal + carritoElemento.getRopa().getPrecio();
		}
		
		model.addAttribute("dineroTotal", precioTotal);
		
		return "carrito";
	}
	
	// Controlador para eliminar un elemento del carrito
	@RequestMapping("/eliminarElementoCarrito")
	public String eliminarElementoCarrito(Model model, HttpSession session, @RequestParam("idCarrito") int idCarrito) {
		
		carritoRepo.deleteByCarritoId(idCarrito);
		
		Optional<Usuario> usuarioLocalizado = usuarioRepo.findById((Integer) session.getAttribute("usuario"));
		
		model.addAttribute("atr_lista_carrito", carritoRepo.findByUsuarioId(usuarioLocalizado.get().getId()));
		
		List<Carrito> carritoPalDinero = carritoRepo.findByUsuarioId(usuarioLocalizado.get().getId());
		
		double precioTotal = 0.0;
		
		for (Carrito carritoElemento : carritoPalDinero) {
			precioTotal = precioTotal + carritoElemento.getRopa().getPrecio();
		}
		
		model.addAttribute("dineroTotal", precioTotal);
		
		return "carrito";
	}
	
	// Controlador para hacer el pago final mandando la factura por correo al usuario
	@RequestMapping("/finalizarPago")
	public String finalizarPago(Model model, HttpSession session) throws MessagingException {
		
		Optional<Usuario> usuarioLocalizado = usuarioRepo.findById((Integer) session.getAttribute("usuario"));

		List<Carrito> carritoPalFinal = carritoRepo.findByUsuarioId(usuarioLocalizado.get().getId());
		
		for (Carrito carritoElemento : carritoPalFinal) {
			
			ProductoComprado pc = new ProductoComprado();
			
			pc.setColor(carritoElemento.getColor());
			pc.setPrecio(carritoElemento.getRopa().getPrecio());
			pc.setRopa(carritoElemento.getRopa());
			pc.setTalla(carritoElemento.getTalla());
			pc.setUsuario(usuarioLocalizado.get());
			
			productoCompradoRepo.save(pc);
			
		}
		
		double precioTotal = 0.0;
		
		for (Carrito carritoElemento : carritoPalFinal) {
			precioTotal = precioTotal + carritoElemento.getRopa().getPrecio();
		}
		
		// Aqui se invoca la funcion para mandar el correo pasandole los datos necesarios
		sendInvoiceEmail("UrlezagaMikel@gmail.com", usuarioLocalizado.get().getNombre(), carritoPalFinal, precioTotal);
		
		TicketFinal tf = new TicketFinal();
		
		tf.setUsuario(usuarioLocalizado.get());
		tf.setPrecioTotal(precioTotal);
		
		// Se guarda el ticket para tener el registro de este en un futuro
		ticketFinalRepo.save(tf);
		
		carritoRepo.deleteByUsuarioId(usuarioLocalizado.get().getId());
		
		return "redirect:/index";
	}
	
	// Funcion para crera un correo personalizado con forma de factura
	// Se recogen los datos necesario y usando la plantilla ya creada se genera el correo
    public void sendInvoiceEmail(String to, String name, List<Carrito> items, double total) throws MessagingException {
        
    	// La libreria que se usa para mandar el correo
    	MimeMessage message = mailSender.createMimeMessage();
        MimeMessageHelper helper = new MimeMessageHelper(message, true);

        // El contexto para Thymeleaf
        Context context = new Context();
        context.setVariable("name", name);
        context.setVariable("items", items);
        context.setVariable("total", total);

        // Generar contenido HTML usando Thymeleaf
        String htmlContent = templateEngine.process("invoice", context);

        helper.setTo(to);
        helper.setSubject("Tu factura");
        helper.setText(htmlContent, true);

        mailSender.send(message);
    }
	
}
