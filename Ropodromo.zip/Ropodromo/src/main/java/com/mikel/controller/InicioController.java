package com.mikel.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import jakarta.servlet.http.HttpSession;

@Controller
public class InicioController {
	
	// Controlador para la llamada de la primera funcionalidad de la web
	@RequestMapping("/")
	public String paginaPrincipal(Model model, HttpSession session) {
		
		// Inicializamos los intentos de inicio de sesion del login
		session.setAttribute("numero_de_intentos", 3);
		
		return "login";
	}
}
