package com.mikel.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name="inventario_colores")
public class InventarioColores {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="id")
	private int id;
	
	@ManyToOne
	private Ropa ropa;
	
	@ManyToOne
	private Color color;

	public InventarioColores(int id, Ropa ropa, Color color) {
		super();
		this.id = id;
		this.ropa = ropa;
		this.color = color;
	}

	public InventarioColores() {
		super();
		this.id = 0;
		this.ropa = new Ropa();
		this.color = new Color();
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Ropa getRopa() {
		return ropa;
	}

	public void setRopa(Ropa ropa) {
		this.ropa = ropa;
	}

	public Color getColor() {
		return color;
	}

	public void setColor(Color color) {
		this.color = color;
	}

	@Override
	public String toString() {
		return "InventarioColores [id=" + id + ", ropa=" + ropa + ", color=" + color + "]";
	}
	
}
