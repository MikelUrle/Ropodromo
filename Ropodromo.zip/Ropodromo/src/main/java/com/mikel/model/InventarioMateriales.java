package com.mikel.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name="inventario_materiales")
public class InventarioMateriales {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="id")
	private int id;
	
	@ManyToOne
	private Ropa ropa;
	
	@ManyToOne
	private Material material;

	public InventarioMateriales(int id, Ropa ropa, Material material) {
		super();
		this.id = id;
		this.ropa = ropa;
		this.material = material;
	}

	public InventarioMateriales() {
		super();
		this.id = 0;
		this.ropa = new Ropa();
		this.material = new Material();
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Ropa getRopa() {
		return ropa;
	}

	public void setRopa(Ropa ropa) {
		this.ropa = ropa;
	}

	public Material getMaterial() {
		return material;
	}

	public void setMaterial(Material material) {
		this.material = material;
	}

	@Override
	public String toString() {
		return "InventarioMateriales [id=" + id + ", ropa=" + ropa + ", material=" + material + "]";
	}
	
}