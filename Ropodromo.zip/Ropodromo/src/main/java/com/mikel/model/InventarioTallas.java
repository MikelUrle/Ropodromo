package com.mikel.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name="inventario_tallas")
public class InventarioTallas {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="id")
	private int id;
	
	@ManyToOne
	private Ropa ropa;
	
	@ManyToOne
	private Talla talla;

	public InventarioTallas(int id, Ropa ropa, Talla talla) {
		super();
		this.id = id;
		this.ropa = ropa;
		this.talla = talla;
	}

	public InventarioTallas() {
		super();
		this.id = 0;
		this.ropa = new Ropa();
		this.talla = new Talla();
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Ropa getRopa() {
		return ropa;
	}

	public void setRopa(Ropa ropa) {
		this.ropa = ropa;
	}

	public Talla getTalla() {
		return talla;
	}

	public void setTalla(Talla talla) {
		this.talla = talla;
	}

	@Override
	public String toString() {
		return "InventarioTallas [id=" + id + ", ropa=" + ropa + ", talla=" + talla + "]";
	}

}
