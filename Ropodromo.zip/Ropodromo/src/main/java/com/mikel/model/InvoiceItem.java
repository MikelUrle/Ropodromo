package com.mikel.model;

public class InvoiceItem {
    private String product;
    private int quantity;
    private double price;
    private double total;

    public InvoiceItem(String product, int quantity, double price) {
        this.product = product;
        this.quantity = quantity;
        this.price = price;
        this.total = quantity * price;
    }

	public String getProduct() {
		return product;
	}

	public void setProduct(String product) {
		this.product = product;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public double getTotal() {
		return total;
	}

	public void setTotal(double total) {
		this.total = total;
	}

	@Override
	public String toString() {
		return "InvoiceItem [product=" + product + ", quantity=" + quantity + ", price=" + price + ", total=" + total
				+ "]";
	}
}
