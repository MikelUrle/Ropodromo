package com.mikel.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name="producto_comprado")
public class ProductoComprado {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="id")
	private int id;
	
	@ManyToOne
	private Ropa ropa;

	@ManyToOne
	private Color color;
	
	@ManyToOne
	private Talla talla;
	
	@ManyToOne
	private Usuario usuario;

	@Column(name="precio")
	private double precio;

	public ProductoComprado(int id, Ropa ropa, Color color, Talla talla, Usuario usuario, double precio) {
		super();
		this.id = id;
		this.ropa = ropa;
		this.color = color;
		this.talla = talla;
		this.usuario = usuario;
		this.precio = precio;
	}

	public ProductoComprado() {
		super();
		this.id = 0;
		this.ropa = new Ropa();
		this.color = new Color();
		this.talla = new Talla();
		this.usuario = new Usuario();
		this.precio = 0.0;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Ropa getRopa() {
		return ropa;
	}

	public void setRopa(Ropa ropa) {
		this.ropa = ropa;
	}

	public Color getColor() {
		return color;
	}

	public void setColor(Color color) {
		this.color = color;
	}

	public Talla getTalla() {
		return talla;
	}

	public void setTalla(Talla talla) {
		this.talla = talla;
	}

	public Usuario getUsuario() {
		return usuario;
	}

	public void setUsuario(Usuario usuario) {
		this.usuario = usuario;
	}

	public double getPrecio() {
		return precio;
	}

	public void setPrecio(double precio) {
		this.precio = precio;
	}

	@Override
	public String toString() {
		return "ProductoComprado [id=" + id + ", ropa=" + ropa + ", color=" + color + ", talla=" + talla
				+ ", usuario=" + usuario + ", precio=" + precio + "]";
	}
	
}

