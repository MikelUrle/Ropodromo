package com.mikel.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name="ticket_final")
public class TicketFinal {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="id")
	private int id;
	
	@ManyToOne
	private Usuario usuario;

	@Column(name="precioTotal")
	private double precioTotal;

	public TicketFinal(int id, Usuario usuario, double precioTotal) {
		super();
		this.id = id;
		this.usuario = usuario;
		this.precioTotal = precioTotal;
	}

	public TicketFinal() {
		super();
		this.id = 0;
		this.usuario = new Usuario();
		this.precioTotal = 0.0;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Usuario getUsuario() {
		return usuario;
	}

	public void setUsuario(Usuario usuario) {
		this.usuario = usuario;
	}

	public double getPrecioTotal() {
		return precioTotal;
	}

	public void setPrecioTotal(double precioTotal) {
		this.precioTotal = precioTotal;
	}

	@Override
	public String toString() {
		return "TicketFinal [id=" + id + ", usuario=" + usuario + ", precioTotal=" + precioTotal + "]";
	}
	
}
