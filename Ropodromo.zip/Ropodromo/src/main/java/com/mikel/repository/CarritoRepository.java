package com.mikel.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.mikel.model.Carrito;

import jakarta.transaction.Transactional;

@Repository
public interface CarritoRepository extends JpaRepository<Carrito, Integer> {
	
    @Query("SELECT ic FROM Carrito ic WHERE ic.usuario.id = :idUsuario")
    List<Carrito> findByUsuarioId(@Param("idUsuario") int idUsuario);
	
    @Modifying
    @Transactional
    @Query("DELETE FROM Carrito ic WHERE ic.usuario.id = :idUsuario")
    void deleteByUsuarioId(@Param("idUsuario") int idUsuario);
    
    @Modifying
    @Transactional
    @Query("DELETE FROM Carrito ic WHERE ic.id = :idCarrito")
    void deleteByCarritoId(@Param("idCarrito") int idCarrito);
}
