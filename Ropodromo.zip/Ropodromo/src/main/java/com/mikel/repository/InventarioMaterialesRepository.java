package com.mikel.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.mikel.model.Color;
import com.mikel.model.InventarioMateriales;

@Repository
public interface InventarioMaterialesRepository extends JpaRepository<Color, Integer> {
	
    @Query("SELECT ic FROM InventarioMateriales ic WHERE ic.ropa.id = :idRopa")
    List<InventarioMateriales> findByRopaId(@Param("idRopa") int idRopa);
	
}
