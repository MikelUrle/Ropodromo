package com.mikel.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.mikel.model.InventarioTallas;

@Repository
public interface InventarioTallasRepository extends JpaRepository<InventarioTallas, Integer> {
	
    @Query("SELECT ic FROM InventarioTallas ic WHERE ic.ropa.id = :idRopa")
    List<InventarioTallas> findByRopaId(@Param("idRopa") int idRopa);
	
}
