package com.mikel.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.mikel.model.Ropa;

import jakarta.transaction.Transactional;

@Repository
public interface RopaRepository extends JpaRepository<Ropa, Integer> {
	
	@Query("SELECT c FROM Ropa c WHERE c.categoria.id = :categoriaid")
	List<Ropa> findByCategoria(@Param("categoriaid") int categoriaid);

	@Query("SELECT c FROM Ropa c WHERE c.estado.id = :estadoid")
	List<Ropa> findByEstado(@Param("estadoid") int estadoid);
	
	@Query("SELECT c FROM Ropa c WHERE c.coleccion.id = :coleccionid")
	List<Ropa> findByColeccion(@Param("coleccionid") int coleccionid);
	
    @Modifying
    @Transactional
    @Query("DELETE FROM Ropa c WHERE c.id = :idRopa")
    void deleteByIdRopa(@Param("idRopa") int idRopa);
    
    @Modifying
    @Transactional
    @Query("UPDATE Ropa c SET c.nombre = :nombre, c.descripcion = :descripcion, c.precio = :precio WHERE c.id = :idRopa")
    void updateRopaById(
        @Param("idRopa") int idRopa, 
        @Param("nombre") String nombre, 
        @Param("descripcion") String descripcion, 
        @Param("precio") double precio
    );
}


